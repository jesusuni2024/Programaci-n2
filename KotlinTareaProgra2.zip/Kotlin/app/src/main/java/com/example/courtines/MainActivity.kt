package com.example.courtines

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView: ListView = findViewById(R.id.usersListView)

        // Observador para la lista de usuarios
        viewModel.users.observe(this) { userList ->
            val userNames = userList.map { "${it.name} (${it.email})" }
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, userNames)
            listView.adapter = adapter
        }

        // Observador para los errores
        viewModel.error.observe(this) { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
        }

        // Iniciar la llamada a la API
        viewModel.fetchUsers()
    }
}