package com.example.courtines

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    val users = MutableLiveData<List<User>>()
    val error = MutableLiveData<String>()

    fun fetchUsers() {
        viewModelScope.launch {
            try {
                users.value = RetrofitInstance.api.getUsers()
            } catch (e: Exception) {
                error.value = "Error al conectar: ${e.message}"
            }
        }
    }
}