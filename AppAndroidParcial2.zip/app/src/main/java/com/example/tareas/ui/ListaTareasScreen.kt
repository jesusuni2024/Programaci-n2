package com.example.tareas.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.tareas.data.TareaRepository
import com.example.tareas.model.Tarea

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListaTareasScreen(navController: NavController) {
    var tareas by remember { mutableStateOf(listOf<Tarea>()) }

    LaunchedEffect(Unit) { TareaRepository.observarTareas { tareas = it } }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Mis Tareas") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("nueva") }) {
                Text("+")
            }
        }
    ) { padding ->
        if (tareas.isEmpty()) {
            Box(Modifier.padding(padding).padding(16.dp)) { Text("Sin tareas aún. Pulsa + para agregar.") }
        } else {
            LazyColumn(Modifier.padding(padding)) {
                items(tareas) { t -> TareaItem(t) }
            }
        }
    }
}

@Composable
private fun TareaItem(t: Tarea) {
    Card(Modifier.fillMaxWidth().padding(8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Nombre: ${t.nombre}", style = MaterialTheme.typography.titleMedium)
            Text("Fecha: ${t.fecha}")
            Text("Responsable: ${t.responsable}")
        }
    }
}
