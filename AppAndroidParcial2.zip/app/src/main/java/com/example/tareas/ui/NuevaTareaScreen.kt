package com.example.tareas.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.tareas.data.TareaRepository
import com.example.tareas.model.Tarea

@Composable
fun NuevaTareaScreen(navController: NavController) {
    var nombre by remember { mutableStateOf("") }
    var fecha by remember { mutableStateOf("") }
    var responsable by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(Modifier.padding(16.dp)) {
        Text("Nueva tarea", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") }, singleLine = true)
        OutlinedTextField(value = fecha, onValueChange = { fecha = it }, label = { Text("Fecha (yyyy-MM-dd)") }, singleLine = true)
        OutlinedTextField(value = responsable, onValueChange = { responsable = it }, label = { Text("Responsable") }, singleLine = true)

        if (error.isNotEmpty()) Text(error, color = Color.Red)

        Button(modifier = Modifier.padding(top = 16.dp), onClick = {
            if (nombre.isBlank() || fecha.isBlank() || responsable.isBlank()) {
                error = "Todos los campos son obligatorios"
            } else {
                val t = Tarea(nombre = nombre.trim(), fecha = fecha.trim(), responsable = responsable.trim())
                TareaRepository.agregarTarea(t) { ok ->
                    if (ok) navController.popBackStack() else error = "Error al guardar"
                }
            }
        }) { Text("Guardar") }
    }
}
