package com.example.tareas.data

import com.example.tareas.model.Tarea
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

object TareaRepository {
    private val db = FirebaseFirestore.getInstance()
    private val collection = db.collection("tareas")

    fun agregarTarea(tarea: Tarea, onComplete: (Boolean) -> Unit) {
        val doc = collection.document()
        val conId = tarea.copy(id = doc.id)
        doc.set(conId).addOnCompleteListener { onComplete(it.isSuccessful) }
    }

    fun observarTareas(onChange: (List<Tarea>) -> Unit) {
        collection.orderBy("fecha", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                val lista = snap?.toObjects(Tarea::class.java) ?: emptyList()
                onChange(lista)
            }
    }
}
