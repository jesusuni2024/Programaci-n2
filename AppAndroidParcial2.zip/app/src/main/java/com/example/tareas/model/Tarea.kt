package com.example.tareas.model

data class Tarea(
    val id: String = "",
    val nombre: String = "",
    val fecha: String = "",
    val responsable: String = ""
)
