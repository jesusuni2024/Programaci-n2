package com.example.clase7

import android.util.Patterns

fun validateEmail (value: String): Pair<Boolean, Int?> {
    return when {
        value.isEmpty() -> Pair(false, R.string.login_screen_validation_email_empty)
        !Patterns.EMAIL_ADDRESS.matcher(value).matches() -> Pair(false, R.string.login_screen_validation_email_invalid)
        else -> Pair(true, null)
    }
}

fun validatePassword(value: String): Pair<Boolean, Int?> {
    return when {
        value.isEmpty() -> Pair(false, R.string.login_screen_validation_password_empty)
        value.length < 6 -> Pair(false, R.string.login_screen_validation_password_short)
        else -> Pair(true, null)
    }
}